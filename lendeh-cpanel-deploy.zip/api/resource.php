<?php
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php';

// جدول‌های مجاز و ستون‌های قابل‌ویرایش هر کدام (برای جلوگیری از درج ستون‌های غیرمجاز)
$TABLES = [
  'news'           => ['title', 'category', 'excerpt', 'date'],
  'government'     => ['title', 'body', 'date'],
  'municipality'   => ['title', 'body', 'date'],
  'tourism'        => ['name', 'category', 'description', 'date'],
  'events'         => ['title', 'date', 'location', 'description'],
  'crisis_alerts'  => ['title', 'level', 'body', 'active', 'date'],
];

$table = $_GET['table'] ?? '';
if (!isset($TABLES[$table])) {
  json_response(['error' => 'جدول نامعتبر است.'], 400);
}
$columns = $TABLES[$table];
$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
  $stmt = $pdo->query("SELECT * FROM `$table` ORDER BY id DESC");
  json_response($stmt->fetchAll());
}

if ($method === 'POST') {
  require_admin();
  $body = get_json_body();
  $insertCols = [];
  $placeholders = [];
  $values = [];
  foreach ($columns as $col) {
    $insertCols[] = "`$col`";
    $placeholders[] = '?';
    if ($col === 'active') {
      $values[] = !empty($body[$col]) ? 1 : 0;
    } else {
      $values[] = clean_str($body[$col] ?? '');
    }
  }
  $sql = "INSERT INTO `$table` (" . implode(',', $insertCols) . ") VALUES (" . implode(',', $placeholders) . ")";
  $stmt = $pdo->prepare($sql);
  $stmt->execute($values);
  $id = $pdo->lastInsertId();
  $row = $pdo->prepare("SELECT * FROM `$table` WHERE id = ?");
  $row->execute([$id]);
  json_response($row->fetch(), 201);
}

if ($method === 'DELETE') {
  require_admin();
  $id = intval($_GET['id'] ?? 0);
  if ($id <= 0) json_response(['error' => 'شناسه نامعتبر است.'], 400);
  $stmt = $pdo->prepare("DELETE FROM `$table` WHERE id = ?");
  $stmt->execute([$id]);
  json_response(['ok' => true]);
}

json_response(['error' => 'متد نامعتبر است.'], 405);
