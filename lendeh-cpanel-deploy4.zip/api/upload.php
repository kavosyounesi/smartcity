<?php
require_once __DIR__ . '/helpers.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') json_response(['error' => 'متد نامعتبر است.'], 405);

// آپلود تصاویر فقط برای کاربران لاگین‌شده مجاز است
$user  = current_user();
$staff = current_staff();
$admin = is_admin();
if (!$user && !$staff && !$admin) json_response(['error' => 'برای آپلود تصویر باید وارد حساب کاربری شوید.'], 401);

if (!isset($_FILES['image']) || $_FILES['image']['error'] !== UPLOAD_ERR_OK) {
  json_response(['error' => 'فایلی برای آپلود دریافت نشد.'], 400);
}

$file    = $_FILES['image'];
$maxSize = 5 * 1024 * 1024; // ۵ مگابایت

if ($file['size'] > $maxSize) json_response(['error' => 'حجم تصویر نباید از ۵ مگابایت بیشتر باشد.'], 422);

$finfo    = finfo_open(FILEINFO_MIME_TYPE);
$mimeType = finfo_file($finfo, $file['tmp_name']);
finfo_close($finfo);

$allowed = ['image/jpeg', 'image/png', 'image/webp', 'image/gif'];
if (!in_array($mimeType, $allowed)) json_response(['error' => 'فقط تصاویر JPG، PNG، WebP و GIF مجاز هستند.'], 422);

$ext       = ['image/jpeg' => 'jpg', 'image/png' => 'png', 'image/webp' => 'webp', 'image/gif' => 'gif'][$mimeType];
$uploadDir = __DIR__ . '/../uploads/';
if (!is_dir($uploadDir)) mkdir($uploadDir, 0755, true);

$filename = bin2hex(random_bytes(12)) . '.' . $ext;
$dest     = $uploadDir . $filename;

if (!move_uploaded_file($file['tmp_name'], $dest)) json_response(['error' => 'خطا در ذخیره‌سازی تصویر.'], 500);

$baseUrl = (isset($_SERVER['HTTPS']) && $_SERVER['HTTPS'] === 'on' ? 'https' : 'http')
           . '://' . $_SERVER['HTTP_HOST'];
$url     = $baseUrl . '/uploads/' . $filename;

json_response(['ok' => true, 'url' => $url]);
