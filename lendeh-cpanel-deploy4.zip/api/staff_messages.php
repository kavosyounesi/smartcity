<?php
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php';

$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
  // فرماندار و مدیر کل همه پیام‌ها را می‌بینند
  $staff = current_staff();
  $admin = is_admin();
  if (!$admin && (!$staff || !in_array($staff['role'], ['admin','governor']))) {
    json_response(['error' => 'دسترسی غیرمجاز'], 401);
  }
  $stmt = $pdo->query("SELECT * FROM staff_messages ORDER BY id DESC");
  json_response($stmt->fetchAll());
}

if ($method === 'POST') {
  $action = $_GET['action'] ?? 'send';

  if ($action === 'reply') {
    $responder = require_staff_role(['admin','governor']);
    $id = intval($_GET['id'] ?? 0);
    $body = get_json_body();
    $reply = clean_str($body['reply'] ?? '', 2000);
    if ($reply === '') json_response(['error' => 'متن پاسخ خالی است.'], 422);
    $pdo->prepare("UPDATE staff_messages SET reply=?, reply_by=?, reply_date=?, status='replied' WHERE id=?")
        ->execute([$reply, $responder['name'], clean_str($body['date'] ?? '', 50), $id]);
    json_response(['ok' => true]);
  }

  // ارسال پیام از طرف مدیر اداره به فرماندار
  $staff = require_staff_role(['department_manager','governor','mayor','admin']);
  $body = get_json_body();
  $subject = clean_str($body['subject'] ?? '', 500);
  $msgBody = clean_str($body['body'] ?? '', 3000);
  if ($subject === '' || $msgBody === '') json_response(['error' => 'موضوع و متن پیام را وارد کنید.'], 422);

  $pdo->prepare("INSERT INTO staff_messages (from_staff_id, from_name, from_department, subject, body, date) VALUES (?,?,?,?,?,?)")
      ->execute([intval($staff['id']), $staff['name'], $staff['department'] ?? '', $subject, $msgBody, clean_str($body['date'] ?? '', 50)]);
  json_response(['ok' => true], 201);
}

if ($method === 'DELETE') {
  require_staff_role(['admin','governor']);
  $id = intval($_GET['id'] ?? 0);
  $pdo->prepare("DELETE FROM staff_messages WHERE id=?")->execute([$id]);
  json_response(['ok' => true]);
}

json_response(['error' => 'متد نامعتبر است.'], 405);
