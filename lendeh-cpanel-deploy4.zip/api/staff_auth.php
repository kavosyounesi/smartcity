<?php
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php';

$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'GET') {
  json_response(['staff' => current_staff()]);
}

if ($method === 'POST') {
  $body = get_json_body();
  $action = $body['action'] ?? 'login';

  if ($action === 'logout') {
    start_staff_session(); $_SESSION = []; session_destroy();
    json_response(['ok' => true]);
  }

  $username = clean_str($body['username'] ?? '', 100);
  $password = is_string($body['password'] ?? null) ? $body['password'] : '';
  $department = clean_str($body['department'] ?? '', 200);

  $stmt = $pdo->prepare("SELECT * FROM staff WHERE username = ?");
  $stmt->execute([$username]);
  $row = $stmt->fetch();

  if (!$row || !password_verify($password, $row['password_hash'])) {
    json_response(['error' => 'نام کاربری یا رمز عبور نادرست است.'], 401);
  }

  // برای مدیران اداره، اگر اداره انتخاب‌شده با رکورد ذخیره‌شده تطابق ندارد خطا بده
  if ($row['role'] === 'department_manager' && $department !== '' && $row['department'] !== $department) {
    json_response(['error' => 'اداره انتخاب‌شده با حساب کاربری شما مطابقت ندارد.'], 401);
  }

  start_staff_session();
  $_SESSION['staff'] = [
    'id'         => intval($row['id']),
    'username'   => $row['username'],
    'role'       => $row['role'],
    'name'       => $row['name'],
    'department' => $row['department'],
  ];
  json_response(['staff' => $_SESSION['staff']]);
}

json_response(['error' => 'متد نامعتبر است.'], 405);
