<?php
require_once __DIR__ . '/helpers.php';
require_once __DIR__ . '/db.php';

$pdo = db();
$method = $_SERVER['REQUEST_METHOD'];

// همه عملیات فقط برای مدیر کل سامانه مجاز است
require_admin();

$DEPARTMENTS = [
  'فرماندار','شهردار','راهداری','آموزش و پرورش','گردشگری','شهرسازی',
  'بنیاد مسکن','جهاد کشاورزی','کتابخانه','ارشاد اسلامی','تربیت بدنی',
  'فنی و حرفه‌ای','دانشگاه','شبکه بهداشت و درمان','آب منطقه‌ای',
  'آب و فاضلاب شهری','اداره برق','اداره گاز','بخشدار مرکزی',
  'بخشدار موگرمون','مدیر بحران','امور عشایری','تعزیرات',
  'تنظیم بازار','مخابرات','هلال احمر','اداره پست','اداره بهزیستی',
  'کمیته امداد','ثبت احوال',
];

if ($method === 'GET') {
  if (isset($_GET['departments'])) {
    json_response($DEPARTMENTS);
  }
  $stmt = $pdo->query("SELECT id, username, role, name, department, created_at FROM staff ORDER BY id ASC");
  $rows = $stmt->fetchAll();
  foreach ($rows as &$r) { $r['id'] = intval($r['id']); }
  json_response($rows);
}

if ($method === 'POST') {
  $body = get_json_body();
  $username   = clean_str($body['username'] ?? '', 100);
  $password   = is_string($body['password'] ?? null) ? $body['password'] : '';
  $role       = in_array($body['role'] ?? '', ['governor','mayor','department_manager']) ? $body['role'] : 'department_manager';
  $name       = clean_str($body['name'] ?? '', 200);
  $department = clean_str($body['department'] ?? '', 200);

  if ($username === '' || strlen($password) < 6 || $name === '') {
    json_response(['error' => 'نام کاربری، رمز عبور (حداقل ۶ کاراکتر) و نام را وارد کنید.'], 422);
  }

  $check = $pdo->prepare("SELECT id FROM staff WHERE username = ?");
  $check->execute([$username]);
  if ($check->fetch()) json_response(['error' => 'این نام کاربری قبلاً ثبت شده است.'], 409);

  $hash = password_hash($password, PASSWORD_DEFAULT);
  $stmt = $pdo->prepare("INSERT INTO staff (username, password_hash, role, name, department) VALUES (?, ?, ?, ?, ?)");
  $stmt->execute([$username, $hash, $role, $name, $department]);
  $id = $pdo->lastInsertId();
  json_response(['ok' => true, 'id' => intval($id)], 201);
}

if ($method === 'DELETE') {
  $id = intval($_GET['id'] ?? 0);
  if ($id <= 0) json_response(['error' => 'شناسه نامعتبر است.'], 400);
  $pdo->prepare("DELETE FROM staff WHERE id = ?")->execute([$id]);
  json_response(['ok' => true]);
}

json_response(['error' => 'متد نامعتبر است.'], 405);
